﻿
namespace Kutuphane_Otomasyonu
{
    partial class yonetim_paneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(yonetim_paneli));
            this.btn_üyelistele = new System.Windows.Forms.Button();
            this.btn_kitapekle = new System.Windows.Forms.Button();
            this.btn_kitaplistele = new System.Windows.Forms.Button();
            this.btn_emanetlistele = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_üyelistele
            // 
            this.btn_üyelistele.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_üyelistele.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_üyelistele.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_üyelistele.Location = new System.Drawing.Point(452, 64);
            this.btn_üyelistele.Name = "btn_üyelistele";
            this.btn_üyelistele.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_üyelistele.Size = new System.Drawing.Size(311, 95);
            this.btn_üyelistele.TabIndex = 1;
            this.btn_üyelistele.Text = "Üye Listele";
            this.btn_üyelistele.UseVisualStyleBackColor = true;
            this.btn_üyelistele.Click += new System.EventHandler(this.btn_üyelistele_Click);
            // 
            // btn_kitapekle
            // 
            this.btn_kitapekle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_kitapekle.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_kitapekle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_kitapekle.Location = new System.Drawing.Point(452, 181);
            this.btn_kitapekle.Name = "btn_kitapekle";
            this.btn_kitapekle.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_kitapekle.Size = new System.Drawing.Size(145, 95);
            this.btn_kitapekle.TabIndex = 2;
            this.btn_kitapekle.Text = "Kitap Ekle";
            this.btn_kitapekle.UseVisualStyleBackColor = true;
            this.btn_kitapekle.Click += new System.EventHandler(this.btn_kitapekle_Click);
            // 
            // btn_kitaplistele
            // 
            this.btn_kitaplistele.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_kitaplistele.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_kitaplistele.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_kitaplistele.Location = new System.Drawing.Point(618, 181);
            this.btn_kitaplistele.Name = "btn_kitaplistele";
            this.btn_kitaplistele.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_kitaplistele.Size = new System.Drawing.Size(145, 95);
            this.btn_kitaplistele.TabIndex = 3;
            this.btn_kitaplistele.Text = "Kitap Listele";
            this.btn_kitaplistele.UseVisualStyleBackColor = true;
            this.btn_kitaplistele.Click += new System.EventHandler(this.btn_kitaplistele_Click);
            // 
            // btn_emanetlistele
            // 
            this.btn_emanetlistele.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_emanetlistele.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_emanetlistele.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_emanetlistele.Location = new System.Drawing.Point(452, 298);
            this.btn_emanetlistele.Name = "btn_emanetlistele";
            this.btn_emanetlistele.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_emanetlistele.Size = new System.Drawing.Size(311, 95);
            this.btn_emanetlistele.TabIndex = 5;
            this.btn_emanetlistele.Text = "Emanet Listele";
            this.btn_emanetlistele.UseVisualStyleBackColor = true;
            this.btn_emanetlistele.Click += new System.EventHandler(this.btn_emanetlistele_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 326);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 29);
            this.label1.TabIndex = 7;
            this.label1.Text = "Kütüphane Otomasyonu";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(94, 51);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(255, 251);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.Location = new System.Drawing.Point(735, 12);
            this.button1.Name = "button1";
            this.button1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button1.Size = new System.Drawing.Size(85, 29);
            this.button1.TabIndex = 21;
            this.button1.Text = "ÇIKIŞ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // yonetim_paneli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 453);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_emanetlistele);
            this.Controls.Add(this.btn_kitaplistele);
            this.Controls.Add(this.btn_kitapekle);
            this.Controls.Add(this.btn_üyelistele);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "yonetim_paneli";
            this.Text = "Yönetim Paneli";
            this.Load += new System.EventHandler(this.yonetim_paneli_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btn_üyelistele;
        private System.Windows.Forms.Button btn_kitapekle;
        private System.Windows.Forms.Button btn_kitaplistele;
        private System.Windows.Forms.Button btn_emanetlistele;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}